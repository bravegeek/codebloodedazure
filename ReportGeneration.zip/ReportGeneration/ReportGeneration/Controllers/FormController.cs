﻿using System.Data;
using System.Diagnostics;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReportGeneration.Models;


namespace Report_Generator_Form.Controllers;

public class FormController : Controller
{
    private readonly ILogger<FormController> _logger;
    private readonly AppDbContext _context;


    public FormController(ILogger<FormController> logger, AppDbContext context)
    {
        _logger = logger;
        _context = context;
    }


    public IActionResult RP_Index() {return View(); }


    /*Creating Tags*/
    public IActionResult RP_CreateTags()
    {
        return View();
    }

    [HttpPost]
    public IActionResult RP_AddTags(Tags model)
    {
        _context.Tags.Add(model);
        _context.SaveChanges();
        return RedirectToAction("RP_ViewTags");
    }

    public IActionResult RP_ViewTags()
    {
        var tagList = _context.Tags.ToList();
        return View(tagList);
    }

    public IActionResult RP_DeleteTags(int id)
    {
        var tagInDb = _context.Tags.SingleOrDefault(tags => tags.Id == id); //find where an id in the Db matches the given id
        _context.Tags.Remove(tagInDb); //remove that expense from the DB
        _context.SaveChanges();
        return RedirectToAction("RP_ViewCategories");
    }


    /*Event Management*/

    public IActionResult RP_Category(int? id)
    {
        if (id != null)
        {//editing -> load an expense by id
            var categoryInDb = _context.Categories.SingleOrDefault(categories => categories.Id == id);
            return View(categoryInDb);
        }

        var newCategory = new Category
        {
            Tags = new List<CategoryTags>()
        };
        var availableTags = _context.Tags.ToList();

        var viewModel = new CategoryInfo
        {
            Category = newCategory,
            Tags = availableTags  // Set the list of tags
        };
        return View(viewModel);
    }

    /*Showing all categories in database*/
    public IActionResult RP_ViewCategories()
    {
        var categoryList = _context.Categories.Include(c => c.Tags).ToList();

        // Create a list to hold all tag names
        List<string> tagNames = new List<string>();

        // Add each tag's name to the list
        foreach (var category in categoryList)
        {
            foreach (var tag in category.Tags)
            {
                // Only add the tag if it's not already in the list
                if (!tagNames.Contains(tag.TagName))
                {
                    tagNames.Add(tag.TagName);
                }
            }
        }

        // Pass the list of tags to the view
        ViewBag.TagNames = tagNames;

        return View(categoryList);
    }


    /*Creating or editing a category*/
    [HttpPost]
    public IActionResult RP_AddEditCategoryForm(CategoryInfo model, string[] tags)
    {
        // If adding a new category
        if (model.Category.Id == 0)
        {
            // Check if any tags are selected
            if (tags != null && tags.Length > 0)
            {
                foreach (var tagName in tags)
                {
                    var newTag = new CategoryTags
                    {
                        TagName = tagName,
                        AttnCnt = 0
                    };

                    model.Category.Tags.Add(newTag);
                }
            }
            

            // Adding the new category to the DB
            _context.Categories.Add(model.Category);
        }
        else
        {
            // Edit existing category, making sure the tags are associated
            _context.Categories.Update(model.Category);
        }

        _context.SaveChanges();
        return RedirectToAction("RP_ViewCategories");
    }



    /*Deleting a category*/
    public IActionResult RP_DeleteCategory(int id)
    {
        var categoryInDb = _context.Categories
            .Include(c => c.Tags) // Make sure to load associated tags
            .SingleOrDefault(categories => categories.Id == id);

        if (categoryInDb != null)
        {
            // Remove the associated CategoryTags first
            _context.CategoryTags.RemoveRange(categoryInDb.Tags);

            // Then remove the category
            _context.Categories.Remove(categoryInDb);
            _context.SaveChanges();
        }

        return RedirectToAction("RP_ViewCategories");
    }


    /*Main Data Entry page*/
    public IActionResult EnterDate()
    {
        return View();
    }

    /*Searching for event by date*/
    [HttpPost]
    public IActionResult DataEntry(DateTime date)
    {
        var categories = _context.Categories.Include(c => c.Tags).Where(c => c.Date.Date == date.Date).ToList();

        return View(categories);

    }

    /*Saving Attendance Data*/
    [HttpPost]
    public IActionResult SaveAttendance(List<Category> categories)
    {
        if (categories.Count() > 0)
        {
            foreach (var category in categories)
            {
                // Retrieve the existing category from the database, including its tags
                var existingCategory = _context.Categories.Include(c => c.Tags).FirstOrDefault(c => c.Id == category.Id);

                if (existingCategory != null)
                {
                    // Update the TotAttn value (sum of attendance count)
                    existingCategory.TotAttn = category.Tags.Sum(tag => tag.AttnCnt);

                    // Update the AttnCnt for each tag in the category
                    foreach (var tag in category.Tags)
                    {
                        // Find the existing tag in the category
                        var existingTag = existingCategory.Tags.FirstOrDefault(t => t.Id == tag.Id);
                        if (existingTag != null)
                        {
                            // Only update the AttnCnt, leave TagName and other fields unchanged
                            existingTag.AttnCnt = tag.AttnCnt;

                            // Explicitly mark the CategoryTag entity as modified
                            _context.Entry(existingTag).State = EntityState.Modified;
                        }

                    }

                    // Ensure the category itself is updated
                    _context.Categories.Update(existingCategory);
                }
            }

            // Save the changes to the database
            _context.SaveChanges();
        }

        return RedirectToAction("RP_Index"); // Or wherever you want to redirect after saving
    }






    //REPORT GENERATION

    /*Showing filtered categories based on the given requirements*/

    public IActionResult RP_ViewPastCategories(string? selectedName, DateTime? startDate, DateTime? endDate, List<Tags> selectedTags, bool? events, bool? programs, bool? cafes)
    {
        var categoryList = _context.Categories.AsQueryable();

        // Include the related CategoryTags and then manually map to Tags
        var categoryInfoList = categoryList.Include(c => c.Tags).ToList().Select(c => new CategoryInfo
            {
                Category = c,
                Tags = c.Tags.Select(ct => new Tags { Name = ct.TagName }).ToList() // Map the CategoryTags to Tags
            }).ToList();

        // Applying filters on Category Types
        if (events.HasValue)
            categoryInfoList = categoryInfoList.Where(c => c.Category.Event == events.Value).ToList();

        if (programs.HasValue)
            categoryInfoList = categoryInfoList.Where(c => c.Category.Program == programs.Value).ToList();

        if (cafes.HasValue)
            categoryInfoList = categoryInfoList.Where(c => c.Category.Cafe == cafes.Value).ToList();

        // Filter categories based on selected date range 
        if (startDate.HasValue && endDate.HasValue)
            categoryInfoList = categoryInfoList.Where(c => c.Category.Date >= startDate.Value && c.Category.Date <= endDate.Value).ToList();

        
        return View(categoryInfoList);
    }


    public async Task<IActionResult> RP_VisualReportPage(string? selectedCategoryIds, List<int>? category)
    {
        List<Category> selectedCategories = new List<Category>();
        int totalAttn = 0;

        // Category selection logic
        if (!string.IsNullOrEmpty(selectedCategoryIds))
        {
            var selectedIdsArray = selectedCategoryIds.Split(',');
            List<int> catList = selectedIdsArray.Select(id => int.TryParse(id, out var result) ? result : 0).ToList();
            selectedCategories = _context.Categories.Include(c => c.Tags).Where(c => catList.Contains(c.Id)).ToList();
        }
        else if (category != null && category.Any())
        {
            selectedCategories = _context.Categories.Include(c => c.Tags).Where(c => category.Contains(c.Id)).ToList();
        }

        // Check if selectedCategories contains any data
        if (selectedCategories.Count == 0)
        {
            // Handle empty categories case
            return View("Error", new { message = "No categories selected." });
        }

        // Total Attendance Calculation
        totalAttn = selectedCategories.Sum(c => c.TotAttn);

        // Initialize pieData to hold aggregated CategoryTags
        List<CategoryTags> pieData = new List<CategoryTags>();

        // Loop through each category to aggregate tags and their attendance counts
        foreach (var cat in selectedCategories)
        {

            foreach (var categoryTag in cat.Tags)
            {
                
                // Check if the tag already exists in pieData
                var existingTag = pieData.FirstOrDefault(pt => pt.TagName == categoryTag.TagName);

                if (existingTag != null)
                {
                    // If tag exists, add the attendance count to the existing tag
                    existingTag.AttnCnt += categoryTag.AttnCnt;
                }
                else
                {
                    // If tag doesn't exist, add it to pieData
                    pieData.Add(new CategoryTags
                    {
                        TagName = categoryTag.TagName,
                        AttnCnt = categoryTag.AttnCnt
                    });
                }
            }
        }

        // Pie Chart Data
        var pieChartData = pieData.Select(tag => new ChartDataViewModel
        {
            Tag = tag.TagName,           // Tag name
            Count = tag.AttnCnt,         // Total attendance count for that tag
            Percentage = (double)tag.AttnCnt / totalAttn * 100  // Percentage of total attendance
        }).ToList();

        // Bar Chart Data
        var barChartData = selectedCategories.Select(c => new ChartDataViewModel
        {
            Tag = c.Name,
            Count = c.TotAttn,
            Percentage = (double)c.TotAttn / totalAttn * 100
        }).ToList();

        // ViewBag Items for chart data
        ViewBag.TotCount = totalAttn;
        ViewBag.PieChartTags = pieChartData.Select(c => c.Tag).ToArray();
        ViewBag.PieChartAttnCnts = pieChartData.Select(c => c.Count).ToArray();
        ViewBag.BarChartNames = barChartData.Select(c => c.Tag).ToArray();
        ViewBag.BarChartAttnCnts = barChartData.Select(c => c.Count).ToArray();

        return View(pieChartData); // Return pie chart data to view
    }




    /*Gathering selected events to have their raw data downloaded to an Excel file*/
    public async Task<FileResult> RP_DownloadRawData(string? selectedCategoryIds, List<int>? category) {

        List<Category> selectedCategories = new List<Category>();

        if (!string.IsNullOrEmpty(selectedCategoryIds))
        {
            var selectedIdsArray = selectedCategoryIds?.Split(',');
            List<Int32> catList = new List<Int32>();

            foreach (var item in selectedIdsArray)
            {
                int x = 0;
                Int32.TryParse(item, out x);
                catList.Add(x);
            }

            foreach (var item in catList)
            {
                selectedCategories.Add(_context.Categories.SingleOrDefault(c => c.Id == item));
            }
        }
        else if (category != null && category.Any())
        {
            foreach (var id in category)
            {
                selectedCategories.Add(_context.Categories.SingleOrDefault(c => c.Id == id));
            }
        }

        var fileName = "Category Attendance Data";

        return GenerateExcel(fileName, selectedCategories);
    }

    /*Generating the Excel file to download to computer*/
    private FileResult GenerateExcel(string fileName, IEnumerable<Category> selectedCategories)
    {
        DataTable dataTable = new DataTable("Categories");
        dataTable.Columns.AddRange(new DataColumn[]{
            new DataColumn("Name"),
            new DataColumn("Date"),
            new DataColumn("Tags"),
            new DataColumn("Event"),
            new DataColumn("Program"),
            new DataColumn("Cafe"),
            new DataColumn("Attendance Count")
        });

        foreach (var category in selectedCategories)
        {
            dataTable.Rows.Add(category.Name, category.Date, category.Tags, category.Event, category.Program, category.Cafe, category.TotAttn);
        }

        using (XLWorkbook wb = new XLWorkbook())
        {
            wb.Worksheets.Add(dataTable);
            using (MemoryStream stream = new MemoryStream())
            {
                wb.SaveAs(stream);
                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
        }
    }



    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }


}

