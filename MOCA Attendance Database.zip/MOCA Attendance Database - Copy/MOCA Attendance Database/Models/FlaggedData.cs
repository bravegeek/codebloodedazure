﻿using Microsoft.AspNetCore.Mvc;

namespace MOCA_Attendance_Database.Models
{
        public class FlaggedDataViewModel
        {
            public List<Category> Categories { get; set; }
            public int CurrentPage { get; set; }
            public int TotalPages { get; set; }
        }

}
