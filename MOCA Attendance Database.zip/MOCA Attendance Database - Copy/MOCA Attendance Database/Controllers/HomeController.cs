﻿using System.Data;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MOCA_Attendance_Database.Models;

namespace MOCA_Attendance_Database.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View();
    }
}