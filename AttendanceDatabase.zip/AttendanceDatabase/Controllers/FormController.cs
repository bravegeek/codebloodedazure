﻿using System.Data;
using System.Diagnostics;
using AttendanceDatabase.Models;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using AttendanceDatabase.Data;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AttendanceDatabase.Controllers
{
    public class FormController : Controller
    {
        private readonly ILogger<FormController> _logger;
        private readonly AttendanceDbContext _context;


        public FormController(ILogger<FormController> logger, AttendanceDbContext context)
        {
            _logger = logger;
            _context = context;
        }


        public IActionResult RP_Index() { return View(); }


        /*Showing filtered categories based on the given requirements*/
        [HttpPost]
        public IActionResult RP_ViewPastCategories(String selectedName, DateTime? startDate, DateTime? endDate, List<string> selectedTags, bool? events, bool? programs, bool? cafes)
        {
            var categoryList = _context.EventAttendanceRecords.AsQueryable();
            List<EventAttendanceRecord> temp = new List<EventAttendanceRecord>();
            DateTime today = DateTime.Today;

            //Adding all tags in DB to the filter <div>
            List<String> tagList = new List<String>();
            foreach (var item in categoryList)
            {
                var tagArray = item.Tags.Split(",");
                foreach (var tag in tagArray)
                {
                    tagList.Add(tag.Trim());
                }
            }
            ViewBag.TagList = tagList.Distinct().ToList(); // Removing duplicates and allowing taglist to be accessible in the view

            //Filtering category entries based on user input

            //Filter by name
            if (!string.IsNullOrEmpty(selectedName))
            {
                selectedName = selectedName.Trim();

                var categoriesList = categoryList.ToList();
                categoryList = categoriesList.Where(v => v.EventName.Contains(selectedName, StringComparison.OrdinalIgnoreCase)).AsQueryable();
            }

            //Filter by dates

            if (startDate.HasValue)
            {
                if (endDate.HasValue) { }
                else
                {
                    endDate = today;
                }

                categoryList = categoryList.Where(v => (v.Date.Date >= startDate.Value.Date) & (v.Date.Date <= endDate.Value.Date));
            }

            //Filter by tags
            if (selectedTags != null && selectedTags.Count > 0)
            {
                // Fetch the categories into memory first
                var categoriesList = categoryList.ToList();

                categoryList = categoriesList.Where(v => selectedTags.Any(tag => !string.IsNullOrEmpty(v.Tags) &&
                        v.Tags.Split(',').Select(t => t.Trim()).Contains(tag))).AsQueryable();
            }

            //Filter by type
            if (events == true)
            {
                categoryList = categoryList.Where(v => v.Event == true);
            }
            if (programs == true)
            {
                categoryList = categoryList.Where(v => v.Program == true);
            }
            if (cafes == true)
            {
                categoryList = categoryList.Where(v => v.Cafe == true);
            }

            var filteredCategories = categoryList.ToList();
            return View(filteredCategories);
        }

        /*Gathering selected events to create and display visuals {WIP}*/
        public async Task<IActionResult> RP_VisualReportPage(string? selectedCategoryIds, List<int>? category)
        {
            List<EventAttendanceRecord> selectedCategories = new List<EventAttendanceRecord>();
            int totalAttn = 0;

            if (!string.IsNullOrEmpty(selectedCategoryIds))
            {
                var selectedIdsArray = selectedCategoryIds?.Split(',');
                List<Int32> catList = new List<Int32>();

                foreach (var item in selectedIdsArray)
                {
                    int x = 0;
                    Int32.TryParse(item, out x);
                    catList.Add(x);
                }

                selectedCategories = _context.EventAttendanceRecords.Where(c => catList.Contains(c.Id)).ToList();
            }
            else if (category != null && category.Any())
            {
                selectedCategories = _context.EventAttendanceRecords.Where(c => category.Contains(c.Id)).ToList();
            }

            foreach (var item in selectedCategories) { totalAttn += item.AttendanceCount; }

            var totalAttendees = selectedCategories.Sum(a => a.AttendanceCount);

            //Get Data For Pie Chart
            List<EventAttendanceRecord> tempList = selectedCategories.ToList();
            List<EventAttendanceRecord> pieData = new List<EventAttendanceRecord>();

            for (int j = 0; j <= tempList.Count() - 1; j++)
            {
                EventAttendanceRecord temp = tempList[j];
                int tempAttn = temp.AttendanceCount;

                for (int i = j + 1; i <= tempList.Count() - (i + 1); i++)
                {
                    if (temp.Tags.Equals(tempList[i].Tags))
                    {
                        tempAttn += tempList[i].AttendanceCount;
                        tempList.RemoveAt(i);
                    }
                }
                temp.AttendanceCount = tempAttn;
                pieData.Add(temp);
            }

            var pieChartData = pieData.Select(a => new ChartDataViewModel
            {
                Tag = a.Tags, // You can split or process tags if needed
                Count = a.AttendanceCount,
                Percentage = (double)a.AttendanceCount / totalAttendees * 100
            }).ToList();

            //ViewBag items to pass to view
            ViewBag.TotCount = totalAttn;
            ViewBag.BarChartNames = selectedCategories.Select(c => c.EventName).ToArray();
            ViewBag.BarChartAttnCnts = selectedCategories.Select(c => c.AttendanceCount).ToArray();

            // Passing the data to the view
            return View(pieChartData);

        }

        /*Gathering selected events to have their raw data downloaded to an Excel file*/
        public async Task<FileResult> RP_DownloadRawData(string? selectedCategoryIds, List<int>? category)
        {

            List<EventAttendanceRecord> selectedCategories = new List<EventAttendanceRecord>();

            if (!string.IsNullOrEmpty(selectedCategoryIds))
            {
                var selectedIdsArray = selectedCategoryIds?.Split(',');
                List<Int32> catList = new List<Int32>();

                foreach (var item in selectedIdsArray)
                {
                    int x = 0;
                    Int32.TryParse(item, out x);
                    catList.Add(x);
                }

                foreach (var item in catList)
                {
                    selectedCategories.Add(_context.EventAttendanceRecords.SingleOrDefault(c => c.Id == item));
                }
            }
            else if (category != null && category.Any())
            {
                foreach (var id in category)
                {
                    selectedCategories.Add(_context.EventAttendanceRecords.SingleOrDefault(c => c.Id == id));
                }
            }

            var fileName = "Category Attendance Data";

            return GenerateExcel(fileName, selectedCategories);
        }

        /*Generating the Excel file to download to computer*/
        private FileResult GenerateExcel(string fileName, IEnumerable<EventAttendanceRecord> selectedCategories)
        {
            DataTable dataTable = new DataTable("Categories");
            dataTable.Columns.AddRange(new DataColumn[]{
            new DataColumn("Name"),
            new DataColumn("Date"),
            new DataColumn("Tags"),
            new DataColumn("Event"),
            new DataColumn("Program"),
            new DataColumn("Cafe"),
            new DataColumn("Attendance Count")
        });

            foreach (var category in selectedCategories)
            {
                dataTable.Rows.Add(category.EventName, category.Date, category.Tags, category.Event, category.Program, category.Cafe, category.AttendanceCount);
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dataTable);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
                }
            }
        }



        /*Event Management TO BE DELETED LATER*/

        public IActionResult RP_Category(int? id)
        {
            if (id != null)
            {//editing -> load an expense by id
                var categoryInDb = _context.EventAttendanceRecords.SingleOrDefault(categories => categories.Id == id);
                return View(categoryInDb);
            }
            return View();
        }

        // Display all products
        public IActionResult RP_ViewCategories()
        {
            var categoryList = _context.EventAttendanceRecords.ToList();
            return View(categoryList);
        }

        //Add or Edit event
        [HttpPost]
        public IActionResult RP_AddEditCategoryForm(EventAttendanceRecord model)
        {
            if (model.Id == 0)
            {
                //Adding
                _context.EventAttendanceRecords.Add(model);
            }
            else
            {
                //Editing
                _context.EventAttendanceRecords.Update(model);
            }

            _context.SaveChanges(); //Must be done or else statement above doesnt work

            return RedirectToAction("RP_ViewCategories");
        }

        public IActionResult RP_DeleteCategory(int id)
        {
            var categoryInDb = _context.EventAttendanceRecords.SingleOrDefault(categories => categories.Id == id); //find where an id in the Db matches the given id
            _context.EventAttendanceRecords.Remove(categoryInDb); //remove that expense from the DB
            _context.SaveChanges();
            return RedirectToAction("RP_ViewCategories");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        /*Editing event*/
        public IActionResult EditCategory(EventAttendanceRecord model)
        {
            //Editing
            _context.EventAttendanceRecords.Update(model);
            _context.SaveChanges(); //Must be done or else statement above doesnt work

            return RedirectToAction("RP_ViewCategories");
        }

        /*Delete event*/
        public IActionResult DeleteCategory(int id)
        {
            var categoryInDb = _context.EventAttendanceRecords.SingleOrDefault(categories => categories.Id == id); //find where an id in the Db matches the given id
            _context.EventAttendanceRecords.Remove(categoryInDb); //remove that expense from the DB
            _context.SaveChanges();
            return RedirectToAction("RP_ViewCategories");
        }
    }
}
