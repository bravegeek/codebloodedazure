﻿using Microsoft.AspNetCore.Mvc;

namespace AttendanceDatabase.Controllers
{
    public class MenusController : Controller
    {
        public IActionResult MainMenu()
        {
            return View(); // Ensure MainMenu.cshtml is located in Views/Menus
        }

        public IActionResult DataEntryMenu()
        {
            return View(); // Ensure DataEntryMenu.cshtml is located in Views/Menus
        }

        public IActionResult DailyEntry()
        {
            return View("~/Views/DataEntry/DailyEntry.cshtml"); // Ensure DailyEntry.cshtml is in Views/DataEntry
        }

        public IActionResult EditCalendar()
        {
            return View("~/Views/EditCalendar/EditCalendar.cshtml"); // Ensure EditCalendar.cshtml is in Views/EditCalendar
        }
    }
}
