﻿using Microsoft.AspNetCore.Mvc;
using AttendanceDatabase.Data;
using AttendanceDatabase.Models;
using Microsoft.AspNetCore.Http;

using System.Linq;

namespace AttendanceDatabase.Controllers
{
    public class AccountController : Controller
    {
        
        private readonly AttendanceDbContext _context;

        public AccountController(AttendanceDbContext context)
        {
            _context = context;
        }

        public IActionResult ManageAccounts()
        {
            var accounts = _context.Accounts.ToList();
            return View("~/Views/Accounts/ManageAccounts.cshtml", accounts);
        }

        public IActionResult Create()
        {
            return View("~/Views/Accounts/Create.cshtml");
        }
        public IActionResult Edit()
        {
            return View("~/Views/Accounts/Edit.cshtml");
        }
        /*[HttpPost]
        public IActionResult Delete(int id)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // var accounts = _context.Accounts.ToList();
                    var accountToBeDeleted = _context.Accounts.SingleOrDefault(c => c.Id == id);
                    _context.Accounts.Remove(accountToBeDeleted);
                    _context.SaveChanges();
                    var accounts = _context.Accounts.ToList();
                    return View("~/Views/Accounts/ManageAccounts.cshtml", accounts);
                }

                else
                {

                    TempData["ErrorMessage"] = "Please correct the errors and try again.";
                    return View("~/Views/Accounts/ManageAccounts.cshtml");
                }
                
                
                
            }
            catch(Exception ex) {
                TempData["ErrorMessage"] = $"An error occurred: {ex.Message}";
                return View("~/Views/Accounts/ManageAccounts.cshtml");
            }
            
        }*/
        [HttpPost]
        public IActionResult Delete(int id)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.Id == id);

            if (account == null)
            {
                return NotFound(); // If the account is not found, return 404
            }

            _context.Accounts.Remove(account); // Remove the account from the database
            _context.SaveChanges(); // Save the changes to the database

            return RedirectToAction("ManageAccounts"); // Redirect back to the ManageAccounts page
        }



        [HttpPost]
        public IActionResult Create(Account account)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    _context.Accounts.Add(account);
                    _context.SaveChanges();
                    TempData["SuccessMessage"] = "Account created successfully.";
                    return RedirectToAction("ManageAccounts");
                }
                else
                {
                    TempData["ErrorMessage"] = "Please correct the errors and try again.";
                    return View("~/Views/Accounts/Create.cshtml", account);
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"An error occurred: {ex.Message}";
                return View("~/Views/Accounts/Create.cshtml", account);
            }
        }

        [HttpPost]
        public IActionResult Edit(Account account, int id)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    var accounts = _context.Accounts.ToList();
                    
                    Account accountToBeUpdated = accounts.FirstOrDefault(a => a.Id == id);
                    accountToBeUpdated.Username = account.Username;
                    accountToBeUpdated.Password = account.Password;
                    accountToBeUpdated.role = account.role;
                    _context.SaveChanges();
                    TempData["SuccessMessage"] = "Account modified successfully.";
                    return RedirectToAction("ManageAccounts");
                }
                else
                {
                    TempData["ErrorMessage"] = "Please correct the errors and try again.";
                    return View("~/Views/Accounts/Create.cshtml", account);
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"An error occurred: {ex.Message}";
                return View("~/Views/Accounts/Create.cshtml", account);
            }
        }

    }
}
