﻿using Microsoft.EntityFrameworkCore;
using AttendanceDatabase.Models;

namespace AttendanceDatabase.Data
{
    public class AttendanceDbContext : DbContext
    {
        public AttendanceDbContext(DbContextOptions<AttendanceDbContext> options)
            : base(options)
        {
        }

        public DbSet<EventAttendanceRecord> EventAttendanceRecords { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure EventAttendanceRecord
            modelBuilder.Entity<EventAttendanceRecord>(entity =>
            {
                entity.Property(e => e.EventName)
                    .IsRequired()
                    .HasMaxLength(100); // Event name is required and has a max length of 100 characters

                entity.Property(e => e.IsFlagged)
                    .HasDefaultValue(false); // Default value for IsFlagged is false
            });
        }
    }
}
