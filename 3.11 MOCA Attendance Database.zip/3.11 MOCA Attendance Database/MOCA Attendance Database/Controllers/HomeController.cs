﻿using System.Data;
using System.Diagnostics;
using DocumentFormat.OpenXml.InkML;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MOCA_Attendance_Database.Models;

namespace MOCA_Attendance_Database.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _context;

    // Inject AppDbContext through constructor
    public HomeController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Admin_Index()
    {

        var categoryTagCount = _context.Tags.Count();
        var categoryEventCount = _context.Categories.Count();


        ViewBag.CategoryTagCount = categoryTagCount;
        ViewBag.CategoryEventCount = categoryEventCount;

        ViewData["HideNavbar"] = true;

        return View();
    }

    public IActionResult Staff_Index()
    {
        var categoryEventCount = _context.Categories.Count();
        ViewBag.CategoryEventCount = categoryEventCount;
        ViewData["HideNavbar"] = true;
        return View();
    }

}