﻿using System;
namespace MOCA_Attendance_Database.Models
{
	public class CategoryInfo
	{
		public Category Category { get; set; }
		public List<Tags> Tags { get; set; }
		public CategoryTags CategoryTags { get; set; }
	}
}

