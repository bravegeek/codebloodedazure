﻿using System;

namespace AttendanceDatabase.Models
{
    public class EventAttendanceRecord
    {
        public int Id { get; set; } // Unique ID for the event attendance record
        public string EventName { get; set; } // Name of the event
        public DateTime Date { get; set; } // Date of the event
        public string Category { get; set; } // Category of the event NEEDS TO BE REMOVED
        public bool Event { get; set; } //Type of category
        public bool Program { get; set; }//Type of category
        public bool Cafe { get; set; }//Type of category
        public string Tags { get; set; } // Tags associated with the event
        public int AttendanceCount { get; set; } // Number of attendees
        public bool IsFlagged { get; set; } // Flag for special attention (added for flagging purposes)
    }
}
