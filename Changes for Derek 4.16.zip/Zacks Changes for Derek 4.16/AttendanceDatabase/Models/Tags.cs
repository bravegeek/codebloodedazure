﻿using System;
namespace AttendanceDatabase.Models
{
    public class Tags
    {
        public int Id { get; set; }
        public String Name { get; set; }
    }
}

