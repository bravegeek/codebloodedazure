﻿using Microsoft.AspNetCore.Mvc;
using AttendanceDatabase.Data;
using AttendanceDatabase.Models;
using Microsoft.AspNetCore.Http;

namespace AttendanceDatabase.Controllers
{
    public class LoginController : Controller
    {
        private readonly AttendanceDbContext? _context;
        public IActionResult Login()
        {
            return View("~/Views/Login/Login.cshtml");
        }

        [HttpPost]
        public IActionResult Login(Account account)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var obj = _context.Accounts.Where(a => a.Username == account.Username && a.Password == account.Password).FirstOrDefault();
                    if (obj != null)
                    {
                        HttpContext.Session.SetString("Username", account.Username);
                        return RedirectToAction("~/Views/Menu/MainMenu.cshtml");
                    }
                    else
                    {
                        TempData["ErrorMessage"] = "Incorrect Username or Password";
                        return RedirectToAction("~/Views/Login/Login.cshtml");
                    }
                }
                else
                {
                    return RedirectToAction("~/Views/Login/Login.cshtml");
                }
            }

            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"An error occurred: {ex.Message}";
                return View("~/Views/Login/Login.cshtml");
            }

           



           
        }
    }
}
