﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using AttendanceDatabase.Models;
using AttendanceDatabase.Data;

namespace AttendanceDatabase.Controllers
{
    public class EventsController : Controller
    {
        private readonly AttendanceDbContext _context;

        public EventsController(AttendanceDbContext context)
        {
            _context = context;
        }

        // GET: Display the event creator form
        public IActionResult EventCreator()
        {
            var events = _context.EventAttendanceRecords.ToList(); // Fetch the list of events
            return View(events); // Pass the list to the view
        }

        // POST: Create a new event
        [HttpPost]
        public IActionResult Create(string eventName, DateTime date, string category, string tags, int numberOfWeeks)
        {
            if (ModelState.IsValid) // Check if the model is valid
            {
                // Logic for handling weekly recurring events based on the number of weeks
                for (int i = 0; i < numberOfWeeks; i++)
                {
                    var newEvent = new EventAttendanceRecord
                    {
                        EventName = eventName,
                        Date = date.AddDays(i * 7), // Increment by 7 days for each subsequent event
                        Category = category,
                        Tags = tags,
                        AttendanceCount = 0 // Initialize with 0 attendees
                    };

                    _context.EventAttendanceRecords.Add(newEvent); // Add the new event to the context
                }

                _context.SaveChanges(); // Save changes to the database
                return RedirectToAction("EventCreator"); // Redirect back to the event creator page
            }

            // If the model is not valid, return the same view with the existing events
            var events = _context.EventAttendanceRecords.ToList();
            ViewData["ErrorMessage"] = "Please fix the errors below."; // Optionally set an error message
            return View("EventCreator", events); // Return the same view with the events
        }
    }
}
